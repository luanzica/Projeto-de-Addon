# SubWorld — Ocean Core World
## Relatório da Fase 2: Definição de Bioma (v0.3)

**Alvo:** Minecraft Bedrock Edition 1.26.50
**Base:** Fase 1 validada em jogo (Content Log limpo, biomas `sw:*` confirmados com `/locate`).
**Status:** v0.3 testada em jogo (funciona; ainda há terra firme de areia). **Substituída pela v0.4** — ver `RELATORIO_GERAL_SUBWORLD.md` na raiz de `subworld/` para o estado consolidado, e `RELEVO_INVESTIGACAO.md` para a prova de por que o relevo não afunda.

---

> **ESTADO (v0.9.0, 13/11/2026):** este relatório é cumulativo. A entrega atual é
> `dist/SubWorld_Fase2_v09.mcaddon` (+ `SubWorld_v09_OceanOnly`, `SubWorld_v09_Diagnostico`,
> `SubWorld_v09_DiagFaixa`). As seções 12–17 e 19 citam pacotes das versões v0.6–v0.8 que
> **não são mais gerados**; a única que vale como estado final é a **seção 20**.
> Regenerar com `python3 build_fase2.py`. Visão geral do projeto: `../RELATORIO_GERAL_SUBWORLD.md`, seção 11.

## 1. Entregáveis

| Arquivo | O que é |
|---|---|
| `dist/SubWorld_Fase2_BP.mcpack` | Behavior Pack v0.3 — 7 biomas finais + 14 features + 14 feature rules (129 KB) |
| `dist/SubWorld_Fase2_Cores.mcpack` | Resource Pack — cores de água/grama/folhagem + 7 neblinas subaquáticas |
| `dist/SubWorld_Diagnostico_1Bioma.mcpack` | Mantido: 1 bioma / 2 alvos, para isolar problemas |
| `src/BP_SubWorld_Prototype/` | Fontes (biomes/, features/, feature_rules/) |
| `src/RP_SubWorld_Prototype_Cores/` | Fontes (biomes/ + fogs/) |
| `build_fase2.py` | Gera tudo a partir da tabela de biomas |

## 2. O que mudou em relação à v0.2 (Fase 1)

1. **Profundidade por bioma** — `minecraft:overworld_height` com `noise_type: ocean` (6 oceanos) e `deep_ocean` (Deep Abyss) + `sea_floor_depth` de 6 a 50. Isto ataca diretamente o problema das "ilhas grandes de areia": o relevo herdado dos biomas terrestres passa a ser gerado como relevo oceânico, e não só retexturizado.
2. **Fundo por bioma** — `top_material` / `mid_material` / `foundation_material` / `sea_floor_material` conforme a spec: areia dominante (Tropical, Shallow, Frozen, Dead, Volcanic), cascalho (Deep Abyss), pedra (Volcanic).
3. **Manchas de material** — `minecraft:surface_material_adjustments` (ruído por bioma): cascalho e argila no Tropical, argila no Frozen e no Dead, pedra no Volcanic, areia no Deep Abyss.
4. **Clima** — temperatura/queda conforme a spec (Tropical 0.9/0.8 quente-úmido; Frozen −0.5 com acúmulo de neve; Volcanic 1.2/0.0; Deep Abyss 0.2/0.1; Dead 0.5/0.2).
5. **Flora e decoração** — features + feature rules com `biome_filter` por tag própria de cada bioma:
   - Kelp Forest: `kelp` (40 iterações) + `seagrass` (18) + `sea_pickle` (4)
   - Tropical: `seagrass` (14) + `coral` (6) + `sea_pickle` (3)
   - Shallow: `seagrass` (16) + `coral` (10) + `sea_pickle` (4)
   - Deep Abyss: `seagrass` (3) + `magma` (1)
   - Volcanic: `magma` (5)
   - Frozen: `ice` (8) — gelo/gelo compactado/gelo azul
   - Dead: `dead_coral` (8) — corais mortos, sem nenhuma planta
6. **Cores + neblina** — RP agora define `fogs/*.json` e aponta `minecraft:fog_appearance` em cada client biome (Tropical #00AB94/64, Shallow #41B1BF/80, Kelp #13594A/48, Frozen #002A52/40, Volcanic #A32000/32, Abyss #001F30/24, Dead #657D7C/40).
7. **Tags** — cada bioma tem tag própria (`sw_tropical`, `sw_shallow`, `sw_kelp`, `sw_frozen`, `sw_volcanic`, `sw_abyss`, `sw_dead`) usada pelos filtros das features. A tag `monster` (que alimenta spawn de afogados) ficou **apenas** em Tropical e Shallow; saiu de Kelp, Deep Abyss, Volcanic e Dead, que pela spec não têm afogados.

## 3. Decisões e limitações técnicas (importante)

- **Corais** — desde 1.20.80 o Bedrock separou os IDs por cor: `minecraft:tube_coral`, `brain_coral`, `bubble_coral`, `fire_coral`, `horn_coral` (planta), `*_coral_block` e as versões mortas `dead_*_coral` / `dead_*_coral_block`. Se o Content Log reclamar de algum, é aí que se troca pelo ID legado (`coral_block` + state `coral_color`).
- **Algas (kelp)** — colocadas como bloco único (`minecraft:kelp`) no fundo; o bloco cresce sozinho por random tick e chega perto da superfície com o tempo (a spec pede algas que "chegam bem próximo da superfície"). Em mundo recém-criado elas aparecem curtas.
- **Pepino do mar** — ainda **não existe bloco customizado** (não há textura no repositório). Foi usado `minecraft:sea_pickle` como stand-in funcional. Textura + bloco próprio ficam para quando houver arte.
- **"Gorgônias"** — as ventarolas (`*_coral_fan`) não entraram nesta versão: exigem estado de direção e parede/assoalho. Ficam para a próxima rodada junto do modelo 3D próprio.
- **Icebergs** — o gelo do Frozen é colocado como bolsões no fundo (`ice`/`packed_ice`/`blue_ice`), **não** como icebergs na superfície: iceberg é estrutura pré-montada (`structure_template_feature`), não decoração por ruído. Precisa de modelos/structure blocks.
- **Ravinas do Volcanic** — carvers não são orientáveis por bioma no JSON de bioma; "ravinas subaquáticas longas" exigem trabalhar `minecraft:overworld_height` com `noise_params` customizados ou estrutura própria.
- **Vilas / estruturas** — continuam vanilla e sem deslocamento para o fundo do mar (Fase 4).
- **Spawns** — não há `spawn_rules` próprios; o controle atual é por tag, o que é grosseiro (afeta todos os monstros do bioma, não só o afogado).
- **`com uma variável de cada vez`** — esta versão muda relevo **e** decoração **e** neblina ao mesmo tempo. Se o terreno ficar estranho (paredões entre biomas, costa em degrau), a variável a testar isolada é `overworld_height` (trocar `ocean` por `lowlands` ou remover o componente).

## 4. Checklist de validação (no jogo)

1. Mundo novo, 3 seeds. Content Log deve continuar limpo (atenção a `coral`, `kelp`, `seapickle`, `fog`).
2. **Existe terra firme acima do nível do mar?** Quantos blocos? (objetivo da Fase 5)
3. Ao entrar em cada bioma (use `/locate biome sw:tropical_ocean` etc.): a água muda de cor e a neblina fecha na distância certa?
4. Tropical/Shallow: corais e erva marinha aparecem no fundo?
5. Kelp: as algas estão crescendo em colunas (mesmo que curtas de início)?
6. Dead: só coral morto, nenhuma planta e nenhum mob?
7. Volcanic: magma no fundo, pedra aparecendo nas encostas?
8. Frozen: bolsões de gelo no fundo?
9. Deep Abyss: fundo bem mais fundo que os outros e água quase preta?
10. O fundo respeita a profundidade da spec? (Tropical 15–20, Shallow 5–7, Kelp 12–20, Frozen 20–28, Volcanic 25–35, Dead 9–15, Abyss 45–55)

## 5. Pendências para as próximas fases

- Fase 3: Árvore Ocepânia (bloco + modelo + folhas opacas + sapling + bagas), ilhas e vegetação de superfície.
- Fase 4: estruturas vanilla no fundo do mar, vilas por bioma, vilas flutuantes com esponja.
- Fase 5: item Baga Azul e efeitos.
- Fase 2b (técnica): ventarolas de coral, pepino do mar com textura própria, icebergs como estrutura, ravines no Volcanic, `spawn_rules` para afogados/peixes.

## 6. Histórico (continuação)

- Fase 1 (v0.1 → v0.2): protótipo validado em jogo; correção de `targets` com namespace e de UUID duplicado.
- **Fase 2 (v0.3, esta entrega):** profundidade por bioma, fundo por bioma, manchas de material, clima, flora/decoração (kelp, erva marinha, corais, corais mortos, pepino do mar stand-in, magma, gelo), tags por bioma, neblina por bioma. Validação estática: 53 JSONs, 14 features + 14 regras sem referência órfã, 7 neblinas resolvidas, 3 `.mcpack` íntegros. **Teste em jogo pendente.**

---

## 12. Pepino-do-mar — conferência no wiki PT (`pt.minecraft.wiki/w/Pepino-do-mar`)

**Dúvida:** o "pepino do mar" do briefing existe no jogo com esse nome em português, e como ele se comporta?

**Resposta do wiki (fonte oficial):**
- O bloco é `minecraft:sea_pickle` (ID numérico 411) e o **nome em PT-BR da Edição Bedrock é literalmente "Pepino-do-mar"** (chave `tile.sea_pickle.name`). Ou seja, usar `minecraft:sea_pickle` não é só "stand-in": o jogador vê o nome certo no jogo.
- **Geração natural:** colónias no **fundo de oceanos quentes**, apoiadas **no topo de blocos de coral** em recifes. Cada chunk tem **1/6** de chance de gerar colónias, em grupos de **1 a 4** pepinos.
- **Estados do bloco:** `pickles` 1–4 e `waterlogged` (padrão `true`). Emite luz **só quando inundado**: 1 pepino = 6, 2 = 9, 3 = 12, 4 = 15. Fora da água fica "seco" e não brilha.
- Na **Edição Bedrock** só pode ser colocado em **blocos completos** (diferente do Java, que aceita blocos não sólidos).
- **Farinha de ossos** aumenta a colónia e espalha pepinos para blocos de **coral vivo** vazios até 2 blocos de distância; não precisa de luz.

**O que nosso pack faz:** `sw:sea_pickle` (`single_block_feature`) coloca `minecraft:sea_pickle` sobre o fundo do mar, via `sw:snap_sea_pickle` (`snap_to_surface_feature`, `surface: floor`, `allow_underwater_placement: true`), nas regras `*_sea_pickle_rule` de `sw:kelp_forest`, `sw:shallow_ocean` e `sw:tropical_ocean`.

**Correção aplicada na v0.5.1:** o `may_attach_to.bottom` do pepino agora inclui os **5 blocos de coral** (`tube/brain/bubble/fire/horn_coral_block`) além de areia/cascalho/argila/pedra — antes o pepino só nascia no fundo "nu", nunca em cima do recife, que é justamente onde o vanilla o coloca. O `allowed_surface_blocks` do `snap_to_surface_feature` foi atualizado junto (9 blocos).

**Diferenças que ficaram conscientes:**
1. **Tamanho da colónia:** o nosso feature coloca sempre **1** pepino por bloco. As colónias de 1–4 do vanilla dependem do estado `pickles`/`cluster_count`, e o `single_block_feature` não expõe estado de bloco no `places_block`. Para ter colónias seria preciso testar `minecraft:weighted_random_feature`/estado no 1.26.50 — **não testado**, fica como pendência.
2. **Brilho:** o estado `waterlogged` tem padrão `true`, então o pepino gerado dentro da água deve brilhar (6 de luz); se no teste aparecer apagado, é sinal de que o gerador criou o bloco "seco" e precisamos de outra abordagem.
3. **Biomas:** nós também colocamos no `sw:kelp_forest` (frio/profundo); o vanilla só usa oceano quente. Mantido de propósito, por ser o "brilho no fundo" do nosso bioma de algas — se preferir realismo puro, é remover uma linha da tabela `BIOMES`.

---

## 13. v0.6 — batimetria por faixa de profundidade

**Contexto:** o teste do flood foi reprovado ("as colinas de areia voltaram, agora com cascalho e argila") e o mundo Flat foi descartado — o objetivo é mar vasto com profundidade variando por bioma, não um espelho d'água. Ver `RELEVO_INVESTIGACAO.md` seção 8 para o veredito (não há como esculpir terreno por pack).

**O que a v0.6 faz (implementável e sem risco de log):**
- `minecraft:surface_material_adjustments` ganhou **faixas de altura relativas ao mar** via Molang, que antes não existiam:
  - ilha (acima do mar) → material de ilha por bioma (areia em tropical/shallow, gelo/neve em frozen, pedra em volcanic/kelp, deepslate em abyss, cascalho em dead);
  - enseada `y=63 → 52` → areia clara;
  - plataforma `52 → 39` → material base do bioma;
  - talude `39 → 18` → material profundo;
  - abismo `< 18` → rocha.
- Sintaxe exata (bedrock.dev): `"height_range": ["variable.sea_level - 11", "variable.sea_level"]` dentro de `adjustments[].height_range`; `materials` aceita `top_material`, `mid_material`, `foundation_material`, `sea_material` e `sea_floor_material`. As bandas entram **antes** das manchas de ruído antigas, para que as manchas continuem vencendo onde se sobrepõem.
- Diagrama do desenho: `artifacts/bathymetry_profile.png` (gerado por `design_bathymetry.py`).

**O que a v0.6 NÃO faz:** não rebaixa relevo e não remove morro/ilha. As colinas continuam existindo — só passam a ser "ilhas" com material coerente em vez de areia genérica. A altura do fundo é a do seed.

**Pacotes (v0.6):** `SubWorld_Fase2_v06_BP.mcpack` (mundo normal), `SubWorld_v06_OceanOnly.mcpack` (**recomendado para seed oceânico**: cobre os 72 biomas terrestres + os 11 oceânicos), `SubWorld_Fase2_v06_Cores.mcpack`, `SubWorld_v04_Teste_Flood.mcpack`, `SubWorld_Diagnostico_1Bioma.mcpack`.

**Teste sugerido:** mundo novo com seed oceânico + `OceanOnly` + `Cores`. Verificar: (1) o mar fica contínuo e enorme? (2) o fundo muda de material descendo (areia → cascalho/argila → pedra)? (3) Content Log limpo?

**Pendência maior (decisão do usuário):** rota **T** (template de mundo feito fora do jogo) é a única que entrega batimetria desenhada tipo Subnautica; exige PC com Amulet/WorldPainter. Rota **S** (seed) é a única 100% jogável hoje.

**Correção da causa do "cascalho e argila nas colinas":** as manchas de ruído da v0.3/v0.4 (`top_material: gravel/clay` no Tropical, Kelp, Frozen, Dead, Abyss, Volcanic) **não tinham `height_range`**, então pintavam também terreno acima do mar — foi isso que você viu no teste do flood. Na v0.6 todas receberam `height_range: ["-64", "variable.sea_level"]`, ou seja, **só valem abaixo do nível do mar**. Ilha/morro agora fica com o material de ilha do bioma, sem mancha de cascalho/argila em cima.

---

## 14. Empacotamento: `.mcaddon` (BP + RP num arquivo só)

Pedido do usuário: em vez de instalar BP e RP separados, juntar num `.mcaddon`. Implementado em `build_fase2.py::zip_addon()`: o `.mcaddon` é um zip com **as duas pastas de pack na raiz** (`BP_…/manifest.json` e `RP_…/manifest.json`), formato que o Minecraft reconhece e instala de uma vez.

Gerados (v0.6, 0.6.0):

| Arquivo | Conteúdo |
|---|---|
| `SubWorld_v06_OceanOnly.mcaddon` | BP OceanOnly (149 regras: 72 terrestres + 11 oceânicos) + RP Cores — **recomendado** |
| `SubWorld_Fase2_v06.mcaddon` | BP normal (só biomas terrestres) + RP Cores |
| `SubWorld_v06_Diagnostico.mcaddon` | BP de 1 bioma (`sw:diag_ocean` em plains/forest) + RP Cores |
| `SubWorld_v06_Flood.mcaddon` | BP do experimento de flood + RP Cores |

Os `.mcpack` individuais continuam em `dist/` para quem quiser testar variantes isoladas.

**Mudança necessária no RP:** o `manifest.json` do resource pack dependia do UUID do BP normal; como o mesmo RP agora viaja com 4 BPs diferentes, a dependência foi **removida** — senão as variantes OceanOnly/Diagnostico/Flood acusariam "missing dependency". Os client biomes e fogs casam por identificador, então nada muda visualmente.

**Atenção ao ativar:** num `.mcaddon` o jogo instala os dois pacotes, mas **é preciso ativar os dois** na tela do mundo (aba de comportamento *e* aba de recursos). Se só o BP for ativado, o mundo muda de bioma mas fica sem cor/neblina — e vice-versa.

---

## 15. Fase 2 — "mar dominante" (v0.7) e o mito do bioma faltando

**Regra definida pelo usuário:** na Fase 2 o mar domina o mundo inteiro, usando **os 7 biomas SubWorld + os biomas oceânicos vanilla intactos**; ilhas ficam para a Fase 3.

### 15.1 Cobertura de biomas: já é 100% (verificado)
Auditoria contra a lista oficial de IDs do Bedrock (`pmmp/BedrockData/biome_id_map.json` + `minecraft.wiki/w/Biome/ID`):
- **71 de 71 biomas terrestres** de superfície do Overworld estão em algum `targets` dos 7 biomas. Zero escapatória.
- Falso alarme desfeito: **`mega_taiga_mutated` não existe** no Bedrock — o ID **160 é `redwood_taiga_mutated`** (Old Growth Spruce Taiga), que já estava na lista. Ou seja, não havia bioma faltando.
- Os 3 não-terrestres na lista são de caverna (`lush_caves`, `dripstone_caves`, `deep_dark`) + `sulfur_caves`, todos válidos.

**Consequência:** as ilhas que você vê **não são bioma vanilla sobrando** — são o **relevo** do seed com bioma SubWorld em cima. Bioma não altera altura (seção 8), então a Fase 2 não reduz ilha por essa via. É exatamente o que a Fase 3 vai atacar.

### 15.2 Qual pacote usar na Fase 2
- **`SubWorld_Fase2_v07.mcaddon`** ← o certo para a sua regra: substitui **toda a terra** pelos 7 biomas e **deixa os oceanos vanilla intactos**.
- `SubWorld_v07_OceanOnly.mcaddon` — **não** usar nesta fase: ele também toma os 11 biomas oceânicos vanilla (era para o teste de mundo plano).

### 15.3 Experimento "Mar Alto" (novo)
`SubWorld_v07_MarAlto.mcaddon` — única tentativa legítima de *impor* o mar sem esculpir terreno: enche de água **apenas a faixa y=64..70** (`height_range: ["variable.sea_level + 1", "variable.sea_level + 7"]`). Efeito esperado: **costa e ilhas baixas ficam submersas**, e só o relevo acima de ~70 continua de fora → ilhas mais raras, e **sem** as cachoeiras do flood de altura total (que ia até o topo dos morros).
Risco conhecido: onde a água gerada encosta no oceano (y=63) pode aparecer um degrau/lâmina de água. É um teste para julgar em jogo, não uma entrega final.

### 15.4 Nomenclatura
A versão subiu para **0.7.0** e os arquivos foram renomeados de `v06` para `v07` para não confundir nome com versão.

---

## 16. Nível do mar (y=60?) e a variante MarAlto +14

**Observação do usuário:** a água aparece em **y=60**, não em y=63, e ainda há terra firme (ilhas) com frequência, sempre perto de terra.

**Sobre o y:** o nível do mar do Bedrock é a constante **63** — a água ocupa até **y=62** (o bloco 63 é o primeiro de ar). O Molang `variable.sea_level` vale exatamente essa constante, então nossas faixas (`sea_level - 11`, etc.) já estão ancoradas na linha certa. Se a leitura no HUD deu **60**, quase sempre é porque o jogador estava sobre banco raso/`sea_floor` alto ou a água tinha só 1-2 blocos de profundidade naquele ponto (a superfície continua em 62). **Se em mais leituras o mar realmente estiver em 60**, aí sim vale deslocar todas as faixas em -3 (é uma constante em `depth_bands`).

**Sobre "terra de areia":** isso é *nosso* material de ilha, não bioma vanilla sobrando. A banda `ilha (acima do mar)` da v0.6/v0.7 pinta areia em tropical/shallow, pedra em kelp/volcanic, neve/gelo em frozen, deepslate em abyss e cascalho em dead. Então:
- ilha com **areia/cascalho/pedra** = bioma SubWorld funcionando, só o relevo do seed aparecendo;
- ilha com **grama/dirt verde** = aí sim seria vazamento de bioma vanilla (não deveria existir, cobertura é 71/71).

**Variante nova:** `SubWorld_v07_MarAlto14.mcaddon` — água de **y=64 até y=77** (banda `variable.sea_level + 1` até `+14`). Afoga quase toda a terra: só relevo acima de ~77 continua ilha, o que deixa ilhas realmente raras. Comparada com a `MarAlto` (+7, até y=70), afoga o dobro da faixa.
Trade-off honesto: a lâmina d'água acompanha a altura do terreno (o builder não cria superfície plana), então entre y=63 e y=77 a "superfície" fica ondulada — lê como mar raso/plataforma, e é justamente onde o MarAlto pode parecer estranho. É a única forma de afogar terra sem script (briefing proíbe loop de blocos) e sem arquivo de mundo.

**Lembrete da regra da fase:** "o jogo gerar só oceano" não existe no Bedrock (seção 8: bioma não esculpe, dimensão só `void`, height pack gera vazio). O que existe é: **seed** (relevo), **template** (Fase 3 / PC) e **afogar a terra** (essas variantes).

---

## 17. BUG corrigido (v0.7.1): `snow_block` não existe no Bedrock

**Erros relatados no Content Log (teste do `MarAlto`):**
```
[BiomeRegistry][error] minecraft:surface_material_adjustments | 'top_material' block with name 'minecraft:snow_block', failed to resolve.
[BiomeRegistry][error] Loaded client biome but no biome with that name exists: sw:frozen_ocean
[Json][error] ... adjustments[0] -> materials -> top_material: Missing referenced asset minecraft:snow_block
```

**Causa:** `minecraft:snow_block` é o **nome do Java Edition**. No Bedrock o bloco de neve cheio é **`minecraft:snow`** (a camada fina é `minecraft:snow_layer`). Introduzido na v0.6, na banda "ilha" do bioma `sw:frozen_ocean` (`DEPTH_STYLE` em `build_fase2.py`).

**Efeito em cadeia:** o BP do bioma falhou ao registrar → o `client_biome` do RP (`sw:frozen_ocean`) ficou órfão → o segundo erro. Ou seja, **o frozen ocean simplesmente não existia no mundo** desde a v0.6 (ficava com água/cor vanilla do bioma de origem).

**Correção:** `minecraft:snow_block` → `minecraft:snow` (1 ocorrência). Versão **0.7.1**.

**Verificação added:** varredura automática de identificadores Java-only nos JSONs gerados (`snow_block`, `magma_block`, `grass_block`, `terracotta`, `seagrass_block`, `kelp_plant`) → **0 suspeitos**; os 43 ids de bloco usados foram todos conferidos manualmente (`magma`, `clay`, `kelp`, `seagrass`, `sea_pickle`, `deepslate`, `snow`, `packed_ice`, `blue_ice`, corais vivos/mortos).

**Lição para o relatório geral:** todo identificador de bloco precisa ser checado contra a lista do Bedrock antes de entrar no pack — nomes do Java falham silenciosamente (o bioma inteiro não registra), e o único sinal é o Content Log.

---

## 18. v0.7.2 — biomas "sem vida" (peixe e afogado no dead_ocean)

**Sintoma:** `sw:dead_ocean` gerando **peixes e afogados**, quando a spec diz 0%.

**Causa (spawn rules vanilla, conferidas em `Mojang/bedrock-samples`):**
- `drowned.json` → `minecraft:biome_filter: { "test": "has_biome_tag", "operator": "==", "value": "ocean" }` — **só a tag `ocean`**, nada de `monster`.
- `cod`, `salmon`, `tropicalfish`, `nautilus`, `dolphin`, `guardian` → todos exigem `has_biome_tag == "ocean"` (alguns como `salmon` pedem `ocean` **e** `!= warm`).

Como todos os 7 biomas carregavam a tag `ocean` (herança da Fase 1, para o bioma "se comportar" como oceano), peixe e afogado nasciam normalmente. A tag liga as spawn rules; não a temperatura nem a cor.

**Correção:** política `LIFELESS = {dead_ocean, deep_abyss, volcanic_ocean}` no `build_fase2.py`:
1. remove a tag **`ocean`** desses três biomas (mantém `overworld`, `deep`, `sw_*`);
2. adiciona `minecraft:creature_spawn_probability: { "probability": 0.0 }` (zera também os spawns passivos iniciais de chunk).

Resultado esperado: **0 peixe, 0 afogado** em dead/abyss/volcanic; `tropical`, `shallow`, `kelp` e `frozen` continuam com peixe (têm a tag `ocean`).

**Importante para o teste:** mobs já gerados **não despawnam** por causa do pack, e chunk já gerado não roda spawn rule de novo. Testar em **trecho novo** (ou `/kill @e[type=cod]`, `/kill @e[type=drowned]` e andar 500+ blocos).

**Efeito colateral aceito:** sem a tag `ocean`, o bioma deixa de receber features vanilla que filtram por ela (nós usamos só features próprias com tags `sw_*`) e deixa de ser alvo de regras de spawn oceânicas — que é exatamente o objetivo.

---

## 19. v0.8.0 — algas no dead_ocean e afogamento máximo

### 19.1 Algas (kelp/seagrass) no dead_ocean
**Causa:** não vinham do nosso pack (o decor de `sw:dead_ocean` só tem `dead_coral`). Vinham das **feature rules vanilla**, que filtram por biome tag. As tags `ocean` e `overworld` no nosso bioma autorizavam o jogo a rodar kelp/seagrass/coral vanilla ali — a mesma raiz do problema de peixe/afogado (seção 18).

**Correção:** a política `LIFELESS` agora remove **`ocean` E `overworld`**:
- sem `ocean` → nenhuma spawn rule aquática (peixe, drowned);
- sem `overworld` → nenhuma feature vanilla (kelp, seagrass, coral).

Aplicado a `dead_ocean`, `deep_abyss` e `volcanic_ocean`. Sobram as features próprias, guiadas pelas tags `sw_*` (`sw_dead` → só coral morto; `sw_abyss` → seagrass raro + magma; `sw_volcanic` → magma).
Tags resultantes: `deaf_ocean` → `["sw_dead"]`; `deep_abyss` → `["deep", "sw_abyss"]`; `volcanic_ocean` → `["sw_volcanic"]`.

### 19.2 Escala de afogamento (raridade de ilha)
Tabela **histórica** — esses pacotes foram retirados na v0.9.0 (ver seção 20). Três níveis, mesma mecânica (`surface_material_adjustments` com `height_range` acima do mar):

| Pacote | Água gerada | Ilha só acima de | Efeito |
|---|---|---|---|
| `SubWorld_v08_MarAlto.mcaddon` | y=64..70 | ~70 | suave, costa afogada |
| `SubWorld_v08_MarAlto14.mcaddon` | y=64..77 | ~77 | agressivo |
| **`SubWorld_v08_MarAlto20.mcaddon`** | **y=64..83** | **~83** | **máximo: só picos ficam de fora** |

Quanto mais alta a faixa, mais rara a ilha — e mais espessa a lâmina d'água sobre o terreno (o builder não cria superfície plana, então a "superfície" ondula entre 63 e o topo da faixa). É a troca inevitável: **raridade de ilha × aparência da água**. Se ainda ficar frequente em jogo, o próximo passo é +30 (água até y=93), com o aviso de que aí o visual de "morro de água" volta.

---

## 20. v0.9.0 — o afogamento NÃO funciona (testado em jogo) e o pacote de diagnóstico

### 20.1 O que o teste mostrou
Com o `MarAlto20` (faixa `variable.sea_level + 1 .. + 20`), o usuário leu a superfície da água em **y=63** — o nível do mar da dimensão. Nada mudou: nem mar mais alto, nem ilha submersa.

**Por que:** `surface_material_adjustments` não cria corpo d'água, ele **troca o material da superfície** da coluna. Pintar `minecraft:water` num bloco em y=70 gera uma fonte isolada acima do nível do mar; o fluido escorre, se espalha e assenta em 63. O gerador do Overworld só preenche água **até** `sea_level` = 63, e esse valor não é exposto a behavior pack. Conclusão: **não existe caminho data-driven para elevar o nível do mar nem para submergir relevo acima dele.**

Por isso os pacotes `MarAlto` (+7/+14/+20) e o `Flood` foram **retirados da entrega** (v0.9.0). O código continua no gerador atrás de `EXPERIMENTOS = False`, com a nota de que falharam em jogo, para não perdermos o histórico.

### 20.2 Pacote de diagnóstico (para fechar a dúvida em um teste)
`SubWorld_v09_DiagFaixa.mcaddon` pinta a faixa **y=64..70 com cascalho** (bloco sólido, sem física de fluido) nos 7 biomas. Interpretação:

| O que você vê | Conclusão |
|---|---|
| Cascalho acima do terreno (topo de morro com "chapéu" de cascalho) | A faixa **é aplicada** (Molang e `height_range` funcionam). O fracasso do afogamento é só a física da água → afogamento está morto, sem alternativas. |
| Nada muda | A faixa **não é aplicada** (expressão `variable.sea_level` não avaliada nesse componente). Ainda resta tentar `height_range` com números fixos (`"63"`..`"70"`), já que o nível do mar do Overworld é constante. |

Precisa de **mundo novo ou chunks novos** — bioma e superfície não se reescrevem em chunk já gerado.

### 20.3 Caminho para a Fase 3 (ilhas raras)
Sem alavanca de terreno no pack, sobram duas rotas reais:
1. **Seed escolhida** — gerar mundos candidatos e confirmar com `/locate biome sw:dead_ocean` que não há continente grande por perto. É o caminho mais barato, mas exige tentativa no aparelho.
2. **Mundo-template `.mcworld`** — mundo pré-gerado/editado (PC ou editor de mundo Bedrock) com o relevo já recortado, distribuído junto do addon. É o único jeito de ter ilhas realmente raras e controladas.
