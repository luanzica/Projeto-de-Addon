# SubWorld — Ocean Core World · **PASSAGEM DE BASTÃO**

> **Para quem continua:** leia este arquivo inteiro antes de tocar em qualquer coisa.
> Ele substitui a necessidade de reler a conversa. As seções 3 (histórico), 5 (lições técnicas) e 9 (pendências) são as críticas.
>
> **Projeto:** transformar o Overworld do Minecraft Bedrock 1.26.50 em um mundo aquático (estilo Subnautica) usando geração nativa, sem scripts/loops e sem mobs de combate novos.
> **Autoria/origem:** pedido do usuário `luanzica`; briefing completo em `SubWorld (Projeto).txt`.
> **Repositório de assets:** https://github.com/luanzica/Projeto-de-Addon
> **Ambiente de trabalho:** workspace cloud (sem Minecraft). **Todo teste em jogo é feito pelo usuário.**
> **Última atualização deste documento:** 13/11/2026, fechamento da sessão que entregou a **v0.9.0** (Fase 2 consolidada, afogamento descartado, diagnóstico de faixa pendente).
> **Para retomar em 1 minuto:** leia a seção **11 (Retomada rápida)**.

---

## 1. Resumo do briefing original (`SubWorld (Projeto).txt`)

5 fases, resumidas:

| Fase | Conteúdo |
|---|---|
| 1 | Protótipo "Ocean World Biome Override": BP mínimo com 7 oceanos customizados (Tropical, Deep Abyss, Frozen, Kelp, Volcanic, Shallow, Dead) substituindo **todos** os biomas terrestres e subterrâneos via `minecraft:replace_biomes`, `amount: 1.0`. Validar em jogo. |
| 2 | Definição final dos biomas: blocos, profundidade (5–7 no Shallow … 45–55 no Abyss), cores hex de água/grama/folhagem/neblina, fauna/flora permitida e proibida. |
| 3 | Árvore **Ocepânia** (tronco esverdeado, folhas tipo alga, só submersa, 5 blocos / small 3, máx. 128 por bioma, 12–17 blocos de distância, só em Tropical/Kelp/Shallow, cai 4 madeira de carvalho na bancada) + **ilhas** (terra no centro, areia nas bordas, árvore vanilla por bioma). |
| 4 | Estruturas vanilla realocadas para o fundo do mar (menos vilas/mansão/inglu, que vão para ilhas); vilas flutuantes com esponja úmida; estilo de vila por bioma. |
| 5 | Item **Baga Azul / Baga Oceânica** (2 fome, 2.4 saturação, cura 4, Respiração Aquática 3 min, 42% de drop 1–3 ao quebrar folha, 2.1% de muda, 2 corante azul, alimenta náutilo/golfinho, substituto de tinta brilhante). |

Regras do projeto que **não** podem ser quebradas: nada de mobs/combate novos na Fase 1; nada de script em loop substituindo blocos; nada de comandos repetitivos; pack pequeno; e **relatório a cada teste**.

---

## 2. Estado atual (o que está pronto e validado)

### Fase 1 — ✅ VALIDADA EM JOGO
- 7 biomas `sw:*` substituindo **72** biomas vanilla (terrestres + costeiros + rios + subterrâneos), `amount: 1.0`, alvos disjuntos (sem sobreposição), nenhum oceano vanilla tocado.
- Teste do usuário: **Content Log limpo**; biomas `sw:tropical_ocean` e `sw:kelp_forest` encontrados com `/locate`; cores identificáveis com o RP.
- Artefatos: `subworld/Fase1/dist/SubWorld_Prototype_Fase1_BP.mcpack` (v0.2), `..._Cores.mcpack`, `SubWorld_Diagnostico_1Bioma.mcpack`.

### Fase 2 — ✅ CONSOLIDADA NA v0.9.0 (último teste pendente)
Validado em jogo pelo usuário: Content Log limpo, fundo por bioma, clima, 14 features/regras (kelp, seagrass, coral, dead_coral, sea_pickle, magma, gelo), 7 neblinas, batimetria por faixa, cores do RP e biomas achados por `/locate`.
Corrigido por teste: `snow_block`→`snow` (v0.7.1); peixe/afogado no `dead_ocean` (v0.7.2); kelp/seagrass no `dead_ocean` (v0.8.0).
**Testado e reprovado:** elevar o mar acima de y=63. Com o `MarAlto20` (água de 64 a 83) a superfície continuou em **y=63**. Motivo em `Fase2/RELATORIO_FASE2_SUBWORLD.md` seção 20: trocar material de superfície não cria corpo d'água, e o `sea_level` do Overworld não é exposto a behavior pack.
**Entrega atual (v0.9.0) — `subworld/Fase2/dist/`:**
- `SubWorld_Fase2_v09.mcaddon` — **padrão** (7 biomas SubWorld; oceanos vanilla intactos).
- `SubWorld_v09_OceanOnly.mcaddon` — também toma os oceanos vanilla (para mundo plano; não usar na Fase 2).
- `SubWorld_v09_Diagnostico.mcaddon` — 1 bioma (`sw:diag_ocean`) sobre plains/forest.
- `SubWorld_v09_DiagFaixa.mcaddon` — **diagnóstico novo, não testado** (cascalho em y=64..70).
- `.mcpack` individuais (BP e Cores) para quem preferir instalar separado.
Retirados da entrega: `MarAlto` +7/+14/+20 e `Flood` (código preservado atrás de `EXPERIMENTOS = False`).

#### 2.1 O que falta testar (dois testes curtos)
1. **v0.9.0 — biomas estéreis.** Mundo novo com `SubWorld_Fase2_v09.mcaddon`; ir a um `sw:dead_ocean` (`/locate biome sw:dead_ocean`) e conferir: **0 peixe, 0 afogado, 0 kelp/seagrass**. `dead_ocean`, `deep_abyss` e `volcanic_ocean` perderam as tags `ocean` e `overworld` e têm `creature_spawn_probability: 0.0`.
2. **DiagFaixa — decide o futuro do relevo.** Mundo novo com `SubWorld_v09_DiagFaixa.mcaddon` e olhar um morro: cascalho no topo (faixa aplicada) ou nada (faixa ignorada). Interpretação na seção 20.2 do relatório da Fase 2.

### Fase 3, 4, 5 — ❌ NÃO INICIADAS

### Pendência imediata (define o rumo da Fase 3)
"Mar por todo o mundo, com ilhas raras" não se resolve por pack: bioma não esculpe terreno, dimensão custom só aceita `void`, pacote de altura gera vazio (5.3 / `Fase2/RELEVO_INVESTIGACAO.md` seção 8), e a tentativa de elevar o mar acima de y=63 falhou em jogo (relatório Fase 2, seção 20).
Sobram **duas rotas reais**, aguardando escolha do usuário:
- **Rota S — seed:** mundo com seed escolhida, conferida com `/locate biome sw:dead_ocean`; ilhas raras dependem do relevo da seed.
- **Rota T — mundo-template `.mcworld`:** mundo pré-gerado/editado fora do jogo (Amulet/WorldPainter, PC) e distribuído junto do addon; única forma de desenhar batimetria e ilhas controladas.

---

## 3. Histórico completo da conversa (ordem cronológica)

1. **Usuário:** baixar o zip do repositório e ler primeiro `SubWorld (Projeto).txt`.
2. **Agente:** baixou `main.zip`; dentro havia só `Addon & Outros.zip` (`Better-Biomes.mcaddon` + `ocepania_texture_block.zip`). Nenhum `.txt` — nem na raiz, nem dentro dos pacotes, nem no histórico Git (28 arquivos já enviados, incluindo os apagados). Reportou o conteúdo real do addon de referência.
3. **Usuário:** o txt está dentro de `SubWorld (Projeto).zip`; ia subir no repositório; pediu para esperar.
4. **Agente:** polling do repositório; baixou `SubWorld (Projeto).txt` (15.660 bytes, 205 linhas) e leu tudo; resumiu as 5 fases; confirmou na doc que `replace_biomes` exige `format_version ≥ 1.21.110`.
5. **Usuário:** autorizou a Fase 1 (7 oceanos, `amount 1.0`, ajustar `noise_frequency_scale`, `.mcpack` + relatório, explicar limites do `replace_biomes`) e pediu para procurar a capa `.jpeg` no repositório e recortá-la em quadrado centralizado.
6. **Agente (v0.1):** encontrou `subworld_thumb.jpeg` (1408×768), recortou quadrado central 768×768, gerou `pack_icon.png` 256×256; montou BP com 72 alvos **sem namespace** (seguindo a doc oficial); gerou 3 `.mcpack` com **UUID repetido** entre variantes.
7. **Usuário:** testou → erros no Content Log (`No biome found with name: 'plains'`, `Missing referenced asset ...`, `Loaded client biome but no biome with that name exists: sw:...`) e nasceu em terra firme. O `_NS` dava os mesmos erros.
8. **Agente (v0.2):** diagnosticou as duas causas — (a) `targets` precisam de namespace `minecraft:` (a doc oficial diz o contrário, o runtime desmente; o addon de referência usa com namespace); (b) UUID duplicado fazia o jogo tratar as variantes como o mesmo pacote. Corrigiu, deu UUID próprio a cada pack, removeu a variante `_NS` e criou o pacote de diagnóstico de 1 bioma.
9. **Usuário:** testou → **sem erros no Content Log**; viu `kelp_forest` e `tropical_ocean` (identificados com `/locate` e pelo RP de cores); muita "terra firme de areia"; nenhuma vila; altura/profundidade irregular. Autorizou a Fase 2.
10. **Agente (v0.3):** adicionou `overworld_height` (`ocean`/`deep_ocean`), `sea_floor_depth` 6–50, materiais de fundo por bioma, `surface_material_adjustments` (cascalho/argila/pedra/areia), clima, 14 features + 14 feature rules (kelp, erva marinha, corais vivos, corais mortos, sea_pickle como "pepino do mar", magma, gelo), tags por bioma e 7 neblinas no RP.
11. **Usuário:** testou v0.3 → **ainda nasceu em terra firme e o Tropical continua com grandes extensões de areia seca**; "nem é um mundo dominado por oceano".
12. **Agente (v0.4 + investigação):** descobriu que **`minecraft:overworld_height` é no-op desde o Caves & Cliffs** (doc Microsoft: "It does not change overworld height, and currently only affects map item rendering"). Removê-lo do pack, escreveu `RELEVO_INVESTIGACAO.md` com a prova, listou as 3 rotas e criou o pacote de teste de flood.
13. **Usuário:** escolheu testar o flood primeiro.
14. **Agente:** entregou o `SubWorld_v04_Teste_Flood.mcpack`, avisou do teto técnico (ajustes de material só afetam as camadas de superfície) e sugeriu o teste alternativo de mundo Flat com camadas de água.
15. **Usuário:** pediu para salvar tudo no relatório para outra conta continuar.
16. **Agente:** criou este documento consolidado.
17. **Usuário (nova sessão):** testou o flood → colinas viraram água escorrendo (cachoeiras em todas as direções), muito kelp e pedra; pediu agora **abaixar o relevo e deixar o mar reto e liso em y=63**.
18. **Agente (v0.5):** confirmou na doc de worldgen do Bedrock que *"custom biomes cannot change the shape of the terrain"* (terceira fonte independente) e que dimensões customizadas só suportam gerador `void`; adicionou `minecraft:subsurface_builder`/`noise_gradient` à lista de investigados; criou a variante **OceanOnly** para mundos Flat/Water World e documentou o caminho do mundo plano em `RELEVO_INVESTIGACAO.md` (seção 7).
19. **Usuário:** dúvida sobre o pepino-do-mar → pediu conferência no `pt.minecraft.wiki`.
20. **Agente (v0.5.1):** confirmou no wiki que `minecraft:sea_pickle` **é** o "Pepino-do-mar" em PT-BR; corrigiu o apoio do feature para incluir os 5 blocos de coral (vanilla põe a colónia no topo do recife); documentou em `Fase2/RELATORIO_FASE2_SUBWORLD.md` seção 12.
21. **Usuário:** flood reprovado ("as colinas de areia voltaram, agora com cascalho e argila"), **Flat recusado** — quer mar vasto com profundidade variando por bioma, estilo Subnautica; pediu pesquisa nova e imagens de referência.
22. **Agente (v0.6):** leu as duas páginas oficiais da Microsoft e a bedrock.dev; confirmou que altura de terreno **não** é data-driven no Bedrock (height pack gera **vazio**; dimensão só `void`; bioma não esculpe); implementou **batimetria por faixa** (ilha/enseada/plataforma/talude/abismo com Molang `variable.sea_level`), gerou o diagrama `artifacts/bathymetry_profile.png` e fechou o veredito com as rotas S (seed oceânico + `OceanOnly`) e T (template externo) em `RELEVO_INVESTIGACAO.md` seção 8.
23. **Usuário:** sugeriu juntar BP + RP num `.mcaddon` para agilizar o teste (instalar os dois de uma vez).
24. **Agente:** implementou `zip_addon()` no `build_fase2.py` e gerou 4 `.mcaddon` (OceanOnly, Fase2, Diagnostico, Flood); removeu a dependência de UUID do RP (o mesmo RP viaja com 4 BPs). Documentado em `Fase2/RELATORIO_FASE2_SUBWORLD.md` seção 14.
25. **Usuário:** relatou que nasceu na água (correto), mas há ilhas demais ("frequência alta"); definiu a regra: **Fase 2 = mar dominante no mundo inteiro** (7 biomas SubWorld + oceanos vanilla intactos); **Fase 3** corrige as ilhas.
26. **Agente (v0.7):** auditou a cobertura contra a lista oficial de IDs do Bedrock (`pmmp/BedrockData`) e provou **71/71 biomas terrestres** cobertos — `mega_taiga_mutated` não existe (ID 160 = `redwood_taiga_mutated`, já coberto); concluiu que as ilhas são **relevo**, não bioma; criou o experimento **MarAlto** (água só em y=64..70, sem cachoeiras altas) e renomeou os pacotes para v07/0.7.0. Documentado em `Fase2/RELATORIO_FASE2_SUBWORLD.md` seção 15.
27. **Usuário:** notou a água em **y=60** (não 63) e terra firme frequente perto da costa.
28. **Agente (v0.7b):** explicou que o nível do mar é a constante 63 (água até y=62; leitura 60 = banco raso), que a "terra de areia" é a **nossa banda de ilha** (não bioma vanilla: cobertura é 71/71) e criou a variante **MarAlto14** (água de y=64 a y=77). Documentado em `Fase2/RELATORIO_FASE2_SUBWORLD.md` seção 16.
29. **Usuário:** reportou erros do Content Log no teste do MarAlto (`snow_block` não resolve; `sw:frozen_ocean` sem bioma).
30. **Agente (v0.7.1):** `snow_block` (nome do Java) → `minecraft:snow`; o bioma frozen ocean voltou a registrar e o client biome deixou de ficar órfão; varredura de ids Java-only nos 161 JSONs = 0 suspeitos. Documentado em `Fase2/RELATORIO_FASE2_SUBWORLD.md` seção 17.
31. **Usuário:** no teste do MarAlto, `sw:dead_ocean` apareceu com peixes e afogados (deveria ser 0%), e com terra firme em volta (essa parte é relevo da seed, Fase 3).
32. **Agente (v0.7.2):** achou a causa nas spawn rules vanilla (`drowned` filtra **só** pela tag `ocean`; peixes idem) e criou a política `LIFELESS` (remove tag `ocean` + `creature_spawn_probability 0.0` em dead/abyss/volcanic). Documentado em `Fase2/RELATORIO_FASE2_SUBWORLD.md` seção 18.
33. **Usuário:** algas apareciam no `dead_ocean` (spec pede 0) e pediu para maximizar a raridade das ilhas antes da Fase 3.
34. **Agente (v0.8.0):** algas eram features **vanilla** autorizadas pelas tags `ocean`/`overworld`; `LIFELESS` agora remove as duas (`dead_ocean` ficou só com `sw_dead`). Criou a escala de afogamento +7 / +14 / **+20** (`MarAlto20`: água até y=83, ilha só acima disso). Documentado em `Fase2/RELATORIO_FASE2_SUBWORLD.md` seção 19.
35. **Usuário:** o MarAlto20 não mudou nada — água continua em **y=63**; o afogamento não funcionou.
36. **Agente (v0.9.0):** confirmado o motivo (trocar material de superfície não cria corpo d'água; acima do mar a água escorre e assenta em 63; `sea_level` não é exposto ao pack). `MarAlto` +7/+14/+20 e `Flood` **removidos da entrega** (`EXPERIMENTOS = False`). Criado `SubWorld_v09_DiagFaixa.mcaddon` (cascalho em y=64..70) para decidir entre "faixa não aplicada" e "faixa aplicada, água escorre". Fase 3 encaminhada para seed ou mundo-template. Documentado em `Fase2/RELATORIO_FASE2_SUBWORLD.md` seção 20. **← estado atual**

---

## 4. Onde está cada coisa

```
subworld/
├── RELATORIO_GERAL_SUBWORLD.md        ← ESTE documento (entrada; seção 11 = retomada rápida)
├── Fase1/                             (histórico validado, v0.2 — não usar para teste novo)
│   ├── RELATORIO_FASE1_SUBWORLD.md
│   ├── build.py · src/ · dist/ · artifacts/
└── Fase2/
    ├── RELATORIO_FASE2_SUBWORLD.md    (seções 12–20 = história técnica da Fase 2; seção 20 = afogamento reprovado)
    ├── RELEVO_INVESTIGACAO.md         (prova de por que relevo/mar não são data-driven + rotas S/T/P)
    ├── build_fase2.py                 (gerador único, v0.9.0: tabela BIOMES, DEPTH_STYLE, depth_bands, LIFELESS,
    │                                   EXPERIMENTOS=False, band=<material> para o diagnóstico, zip_addon())
    ├── design_bathymetry.py · artifacts/bathymetry_profile.png
    ├── src/   BP_SubWorld_Prototype · BP_SubWorld_OceanOnly · BP_SubWorld_Diagnostico ·
    │          BP_SubWorld_DiagFaixa · RP_SubWorld_Prototype_Cores
    │          (BP_SubWorld_Flood / _MarAlto* só existem com EXPERIMENTOS=True)
    └── dist/  SubWorld_Fase2_v09.mcaddon · SubWorld_v09_OceanOnly.mcaddon ·
               SubWorld_v09_Diagnostico.mcaddon · SubWorld_v09_DiagFaixa.mcaddon
               (+ .mcpack: SubWorld_Fase2_v09_BP, SubWorld_Fase2_v09_Cores,
                SubWorld_v09_OceanOnly, SubWorld_v09_DiagFaixa_BP, SubWorld_Diagnostico_1Bioma)
```

Fora de `subworld/` (raiz do workspace):
- `addon/` — Better Biomes (addon de referência) extraído; `BP Better Biomes/` e `RP Better Biomes/`.
- `textures/` — 7 PNGs da árvore Ocepania (`log_ocepania`, `log_ocepania_top`, `stripped_ocepania_log` + top, `leaves_ocepania_opaque`, `sapling_ocepania`, `blue_berries`).
- `archives/` — `Better-Biomes.mcaddon` e `ocepania_texture_block.zip`.
- `subworld_thumb.jpeg` — capa original 1408×768.
- `downloads/SubWorld (Projeto).txt` — briefing original (205 linhas).

---

## 5. Lições técnicas (leia antes de escrever JSON novo)

### 5.1 `minecraft:replace_biomes` — alvos PRECISAM de namespace
A doc oficial (1.26.60) diz *"target biomes must not contain namespaces"*. **Está errada na prática.** Sem `minecraft:`, o log cospe `No biome found with name: 'plains'` + `Missing referenced asset plains` e **o arquivo de bioma inteiro é descartado** (o bioma custom nem registra, e o RP reclama "no biome with that name exists"). Formato correto:
```json
"minecraft:replace_biomes": { "replacements": [{
  "dimension": "minecraft:overworld",
  "targets": ["minecraft:plains", "minecraft:desert"],
  "amount": 1.0, "noise_frequency_scale": 1.0 }] }
```
- `amount` ∈ (0,1]; `noise_frequency_scale` ∈ (0,100]. Com `amount: 1.0` a substituição cobre 100% das colunas do alvo.
- **Dois biomas com o mesmo alvo disputam por ruído** (o de menor resultado de ruído vence). Por isso a v0.2+ usa **alvos disjuntos** (72 alvos, 72 únicos).
- Os IDs vanilla da Bedrock são legados: `mesa`, `mesa_bryce`, `swampland`, `roofed_forest`, `cold_taiga`, `ice_plains`, `mushroom_island`, `stone_beach`, `cold_beach`, `extreme_hills_edge`.
- Bioma custom **não pode** usar namespace `minecraft:`.
- Lista completa usada (72 alvos) está em `subworld/Fase2/build_fase2.py`, tabela `BIOMES`.

### 5.2 UUID de manifest
Dois packs com **mesmo `header.uuid` + mesma `version`** são o **mesmo** pacote para o jogo: reimportar não substitui o conteúdo. Cada pack precisa de UUID próprio:
- BP principal `7f1c9a52-3d64-4b8e-9a17-2c5e0b6d4a11` / módulo `a3d84e17-…`
- Diagnóstico `b4e12c78-2a95-4f63-8d07-5c91e6a2f733` / `d0f38a46-…`
- Flood `e7c1f4a9-3b62-4d87-9c05-1a8e5b2f6d99` / `f1d2a873-…`
- RP cores `c5b0f836-…` / `e2a71c48-…`

### 5.3 Relevo: `minecraft:overworld_height` NÃO muda mais a altura
Doc Microsoft (05/03/2026): *"This is a pre-Caves and Cliffs component. **It does not change overworld height**, and currently only affects map item rendering."* Ele é aceito sem erro, o que engana. **Não perca tempo com `noise_type`/`noise_params`.** A lista fechada de componentes de bioma 1.26.60 não tem nenhum campo de altura de terreno; o relevo vem do grafo de ruído 3D do motor.
- `surface_builder` + `sea_floor_depth`/`sea_material` só atuam **abaixo** do nível do mar (y≈63). Acima disso o terreno fica seco, com o `top_material` do bioma → é a origem das "ilhas de areia".
- Único jeito data-driven de pôr água **acima** do nível do mar: `minecraft:surface_material_adjustments` trocando `top_material`/`mid_material` por `minecraft:water` (é o pacote de flood). Teto: afeta só as camadas de superfície; não preenche volume.
- **Testado e confirmado:** `minecraft:surface_material_adjustments` com água em toda a faixa deixa as colinas cobertas de água escorrendo (não nivela).
- `minecraft:noise_gradient` (novo em 1.26.30) e `minecraft:subsurface_builder`: escolhem bloco por ruído 3D na superfície/subsolo — **não mudam altura**; servem para misturar materiais, não para nivelar.
- Frase definitiva da doc de worldgen: *"**Custom biomes cannot change the shape of the terrain**… the landscape is carved by the game first"*.
- Dimensões customizadas (`dimensions/*.json`): **só gerador `void`** — não servem para criar um oceano com terreno.
- Mundo plano no Bedrock: só presets na UI (inclui **"Water World"**, ~90 camadas de água, bioma Deep Ocean); editar camadas exige mexer em `FlatWorldLayers` no `level.dat`. Flat worlds **não geram features nem estruturas**. **Descartado pelo usuário.**
- **Altura data-driven (`BP/dimensions/overworld.json`) = vazio:** aceita só `dimension_bounds.min/max` (múltiplos de 16, -512..512) + `generator_type: "void"`; em mundo novo **nada** gera (nem água, nem bioma, nem feature) e em mundo existente só *esconde* o que está fora da faixa. Não serve para "cortar em y=62".
- **Faixas por profundidade (v0.6):** `surface_material_adjustments[].height_range` aceita Molang (`"variable.sea_level - 11"`) e `materials` aceita `sea_floor_material` — é a forma correta de dar leitura de batimetria sobre relevo alheio.
- Rotas para mundo oceânico de verdade (detalhes em `Fase2/RELEVO_INVESTIGACAO.md`): **A** template de mundo (.mcworld/.mctemplate) gerado no jogo; **B** dimensão customizada `dimensions/*.json`; **C** aceitar o relevo e desenhar ilhas (a Fase 3 já prevê ilhas).

### 5.4 Features (funcionaram na v0.3 — reaproveitar padrão)

**Pepino-do-mar (v0.5.1):** `minecraft:sea_pickle` é o bloco certo e o nome em PT-BR do Bedrock é literalmente **"Pepino-do-mar"** (chave `tile.sea_pickle.name`, ID 411) — conferido em `pt.minecraft.wiki/w/Pepino-do-mar`. No vanilla ele nasce **em cima de blocos de coral** em oceanos quentes, em colónias de 1–4 (1/6 por chunk) e só brilha quando `waterlogged` (6/9/12/15 de luz). Nosso pack agora aceita os 5 blocos de coral como apoio (`ATTACH` no `build_fase2.py`); colónias de 1–4 ainda não são possíveis via `single_block_feature` (sem estado de bloco) — pendência.
Cadeia usada: `feature_rules` → `snap_to_surface_feature` → `single_block_feature`.
```json
{ "format_version": "1.21.60", "minecraft:snap_to_surface_feature": {
  "description": {"identifier": "sw:snap_kelp"},
  "feature_to_snap": "sw:kelp", "surface": "floor",
  "allow_air_placement": false, "allow_underwater_placement": true,
  "vertical_search_range": 96,
  "allowed_surface_blocks": ["minecraft:sand","minecraft:gravel","minecraft:clay","minecraft:stone"] } }
```
- `single_block_feature`: `places_block` aceita lista ponderada `[{"block":{"name":"..."},"weight":N}]`; usar `may_replace: ["minecraft:water","minecraft:seagrass","minecraft:kelp"]` e `may_attach_to.bottom` com os blocos de fundo; `enforce_placement_rules: false`.
- `feature_rules`: `placement_pass` (`first_pass` funcionou), filtro por tag `{"test":"has_biome_tag","operator":"==","value":"sw_kelp"}` e `distribution` com `iterations`, `x/z` uniforme `[0,16]`, `y` uniforme `[-40,90]` (o snap acha o fundo).
- Tags por bioma usadas: `sw_tropical`, `sw_shallow`, `sw_kelp`, `sw_frozen`, `sw_volcanic`, `sw_abyss`, `sw_dead`.
- Blocos aquáticos confirmados: `minecraft:seagrass`, `minecraft:kelp` (cresce por random tick — aparece curto no início), `minecraft:sea_pickle` (usado como **stand-in do "pepino do mar"**, não existe textura própria), `minecraft:magma`, `minecraft:ice`/`packed_ice`/`blue_ice`.
- **Corais:** desde 1.20.80 os IDs foram separados por cor: `minecraft:tube_coral`/`brain_coral`/`bubble_coral`/`fire_coral`/`horn_coral` (planta), `*_coral_block`, e mortos `dead_*_coral` / `dead_*_coral_block`. Ventarolas (`*_coral_fan`) ainda **não** implementadas (precisam de estado de direção).

### 5.5 Resource pack (cores, neblina)
- `RP/biomes/<id>.client_biome.json` com `format_version` `1.21.130`,
  `minecraft:water_appearance.surface_color`, `minecraft:grass_appearance.color`, `minecraft:foliage_appearance.color`, `minecraft:fog_appearance.fog_identifier`.
- `RP/fogs/<id>.json` com `format_version` `1.16.100` e `minecraft:fog_settings.distance.water` (`fog_start`, `fog_end`, `fog_color`, `render_distance_type: "fixed"`).
- O erro "Loaded client biome but no biome with that name exists" significa que o **BP não registrou** o bioma — não é problema do RP.

### 5.6 Ambiente
- Não há Minecraft aqui: **todo teste é do usuário**. Sempre entregar checklist objetivo + pedir Content Log (`Configurações → Criador → Content Log`).
- Sempre validar antes de entregar: `json.load` em todos os arquivos, referências cruzadas (`places_feature`/`feature_to_snap` existem), tags de filtro existem nos biomas, fogs resolvidas, `zipfile.testzip()` nos `.mcpack`, e conferir que nenhum alvo perdeu namespace.

### 5.7 Biome tags controlam spawn e features vanilla (v0.7.2/v0.8.0)
`minecraft:biome > components > minecraft:tags` não é decorativo: as spawn rules vanilla filtram por tag. `drowned.json` usa **só** `has_biome_tag == "ocean"`; cod/salmon/tropicalfish/nautilus/dolphin/guardian idem (`salmon` pede `ocean` e `!= warm`). As features vanilla (kelp, seagrass, coral) dependem de `ocean`/`overworld`. Por isso bioma "estéril" = **sem `ocean` e sem `overworld`** + `minecraft:creature_spawn_probability: { "probability": 0.0 }`. Mobs já gerados e chunks antigos **não** mudam: validar sempre em área nova.

---

## 6. Como regenerar os packs

```bash
cd subworld/Fase2 && python3 build_fase2.py    # v0.9.0: padrão + OceanOnly + Diagnóstico + DiagFaixa
cd subworld/Fase1 && python3 build.py           # v0.2 (histórico)
```
`build_fase2.py` é a fonte única de verdade: tabela `BIOMES` (id, alvos, profundidade, materiais, clima, cores, neblina, decor), `DEPTH_STYLE`/`depth_bands` (batimetria), `LIFELESS` (biomas estéreis), `VER = [0, 9, 0]`, `UUID` (um por variante), `EXPERIMENTOS` (ligar só para reproduzir o afogamento reprovado), `band=<bloco>` no `biome_json()` (diagnóstico de faixa). O build apaga e recria `src/` e `dist/`. Requer Pillow.


---

## 7. Decisões já tomadas (não reabrir sem motivo)

1. Alvos **disjuntos** por bioma (evita disputa de ruído com `amount: 1.0`).
2. `targets` **sempre** com namespace `minecraft:`.
3. Cada pack com **UUID próprio**; versão incrementada a cada entrega (hoje **0.9.0**).
4. Nenhum bioma oceânico vanilla é alvo de substituição (spec).
5. `ice_caves` (ID 196) ficou de fora por ser "upcoming"; se existir no mundo do usuário, adicionar ao Frozen.
6. Capa oficial: recorte **centralizado** da `subworld_thumb.jpeg` (título centralizado) → `pack_icon.png` 256×256.
7. Fase 2 usa `sea_pickle` como pepino do mar e **não** implementa ventarolas/icebergs/ravinas ainda.
8. `dead_ocean`, `deep_abyss` e `volcanic_ocean` são **estéreis**: sem tags `ocean`/`overworld` e com `creature_spawn_probability: 0.0`. Não devolver essas tags — elas religam spawn rules e features vanilla.
9. Afogamento acima do mar está **encerrado**: reprovado em jogo (água assenta em y=63). Só reabrir com prova nova (o `DiagFaixa` pode dar essa prova).
10. O pack padrão é o `SubWorld_Fase2_v09.mcaddon` (oceanos vanilla **não** são alvo); `OceanOnly` é só para mundo plano.

## 8. Armadilhas já pagas (não repetir)
- **Nome de bloco do Java não existe no Bedrock:** `minecraft:snow_block` **quebrou** o bioma `sw:frozen_ocean` inteiro na v0.6/v0.7 (erro `Missing referenced asset`) e só apareceu no Content Log. No Bedrock: neve cheia = `minecraft:snow`, magma = `minecraft:magma`, grama = `minecraft:grass` (não `grass_block`). **Sempre validar id de bloco contra a lista do Bedrock.**

- ❌ Confiar na frase "target biomes must not contain namespaces" da doc.
- ❌ `overworld_height` para tentar afundar o terreno.
- ❌ Reutilizar UUID entre variantes de pack.
- ❌ Achar que `sea_floor_depth` molha terreno acima do nível do mar.
- ❌ Achar que `surface_material_adjustments` com `minecraft:water` **cria** água: ele troca o material da superfície; a água escorre e assenta em y=63.
- ❌ Deixar as tags `ocean`/`overworld` num bioma que deveria ser estéril: `ocean` liga as spawn rules de peixe/drowned e `overworld` liga as features vanilla (kelp/seagrass).
- ❌ Contar com chunk já gerado para validar mudança de bioma/superfície: precisa de mundo novo ou área nova.
- ❌ Editar `.mcpack` manualmente sem rodar o build (o build sobrescreve `src/` e `dist/`).

---

## 9. Pendências e próximos passos (priorizados)

1. **[TESTE] v0.9.0 — biomas estéreis.** Confirmar 0 peixe / 0 afogado / 0 kelp em `sw:dead_ocean` (seção 2.1).
2. **[TESTE] `SubWorld_v09_DiagFaixa.mcaddon`.** Um teste decide se a faixa y=64..70 é sequer aplicada (seção 20.2 do relatório da Fase 2). Se **não** for, ainda cabe tentar `height_range` numérico (`"63"`..`"70"`); se **for**, o afogamento está encerrado de vez.
3. **[BLOQUEANTE] Escolher a rota da Fase 3:** S (seed) ou T (mundo-template `.mcworld`). Só depois disso as ilhas raras avançam.
4. **Fase 2b (independente do relevo):** ventarolas de coral (`*_coral_fan`), pepino com colónia 1–4, icebergs via `structure_template_feature`, ravinas do Volcanic.
5. **Fase 3:** bloco + modelo da Árvore Ocepânia (7 texturas em `textures/`), folhas opacas, sapling, bagas, geração dispersa (máx. 128/bioma, 12–17 blocos de distância) e as ilhas.
6. **Fase 4:** estruturas no fundo do mar, vilas por bioma, vilas flutuantes com esponja úmida.
7. **Fase 5:** item Baga Azul (fome, saturação, cura, Respiração Aquática, corante, alimentar náutilos/golfinhos) — depende do bloco da Fase 3.
8. Sempre: rodar `build_fase2.py`, validar (JSON, zips, ids de bloco) e atualizar este documento + o relatório da fase.

---

## 10. Perguntas abertas para o usuário (quando retomar)

- **Rota S ou T?** (seed oceânica x mundo-template feito fora do jogo) — é o que destrava a Fase 3.
- Se rota T: ele consegue criar o `.mcworld` com relevo oceânico (PC/Amulet/WorldPainter) e subir no repositório?
- A árvore Ocepânia usa as texturas atuais como estão (16×16) ou ele vai refazer a arte?
- O "pepino do mar" é bloco decorativo ou mob passivo? (a spec lista como bloco na Fase 2, mas o nome sugere criatura)
- Vilas flutuantes com esponja: aceita que a vila "flutue" a partir do nível do mar, ou precisa de altura fixa?

---

## 11. Retomada rápida (para a próxima conta)

**Onde o projeto está:** Fase 1 validada em jogo; Fase 2 consolidada na **v0.9.0** (aguardando o teste dos biomas estéreis); Fases 3–5 não iniciadas. O único bloqueio conceitual — "mundo todo mar, ilhas raras" — não tem solução por behavior pack e depende de seed ou de mundo-template.

**Cinco passos para continuar:**

1. `cd subworld/Fase2 && python3 build_fase2.py` — confirma que o gerador roda (precisa de Pillow). Saída esperada: 7 biomas, 72 alvos únicos, 14 regras de feature, `experimentos: desligados`, quatro `.mcaddon` em `dist/`.
2. Ler `Fase2/RELATORIO_FASE2_SUBWORLD.md` seções **18, 19 e 20** — são as três últimas decisões técnicas (spawn por tag, features vanilla por tag, afogamento reprovado).
3. Pedir ao usuário os dois testes da seção 2.1 e **não** reabrir o afogamento sem o resultado do `DiagFaixa`.
4. Com o resultado do `DiagFaixa`, decidir a rota (S ou T) e abrir a Fase 3 pela Árvore Ocepânia (parte da Fase 3 que **não** depende de relevo).
5. Ao entregar qualquer pacote: `.mcaddon` com BP+RP, pedir remoção do addon antigo antes de importar, e exigir mundo/área nova para validar bioma e superfície.

**Não repetir (custou tempo):** tentar afundar ou inundar relevo por pack; confiar na doc sobre alvos sem namespace; usar nome de bloco do Java; deixar as tags `ocean`/`overworld` em bioma que deve ser estéril; testar mudança de bioma em chunk já gerado.

**Arquivos que importam agora:** `Fase2/build_fase2.py` (gerador), `Fase2/dist/SubWorld_Fase2_v09.mcaddon` (entrega padrão), `Fase2/dist/SubWorld_v09_DiagFaixa.mcaddon` (teste pendente), este documento e o relatório da Fase 2.
